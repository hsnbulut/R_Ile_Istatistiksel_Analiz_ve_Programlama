#' @title data1
#'
#' @description The data set is used in Sample 16.1.
#' The data set consists of 2 variables and 10 observations.
#' This data is imaginary.
#'
#' @docType data
#' @keywords datasets
#' @name data1
#' @usage data1
NULL
